var searchData=
[
  ['native_20access_0',['Native access',['../group__native.html',1,'']]]
];
